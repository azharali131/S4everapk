# S4ever Monitor Native Android

This is a native Android project, not Flutter. It is made for online APK build using GitHub Actions / Android online builders.

## Build by mobile using GitHub
1. Create a new GitHub repository.
2. Upload all files/folders from this ZIP to the repository root.
3. Open Actions tab.
4. Run workflow: Build APK.
5. Download artifact: S4ever-Monitor-APK.

## Important
The app sends UDP command `51 4D 4E BB 64 0D` to your inverter IP port 1025.
It displays raw UDP response. Exact live value mapping may still need testing because WiFiMonitor uses a private protocol.
